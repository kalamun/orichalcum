<?
/* INITIAL CHECKS */
$targz='upgrade.tar.gz';
if(!file_exists('tmp/'.$targz)) die('Some files are missing, or you don\'t have write permissions on this directory');
echo 'Upgrading to Orichalcum 2.80...<br />';

error_reporting(E_ALL);

function kRmDir($dir) {
	if(is_dir($dir)&&!is_link($dir)) {
		foreach(glob($dir.'/*') as $sf) {
			if(!kRmDir($sf)) return false;
			}
		return rmdir($dir);
		}
	else {
		return unlink($dir);
		}
	}

function kiTarExtract($file,$dest)
{
	$dest=trim($dest,'/').'/';
	if(!isset($dest)) return false;

	$tar=array();
	$tar['size']=filesize($file);
	$tar['data']=file_get_contents($file);

	$offset=0;
	for($i=0;$offset<$tar['size'];$i++)
	{
		$file=array();
		$file['name']=trim(substr($tar['data'],$offset,100));
		if(substr($file['name'],-1)=="/")
		{ //dir
			$file['size']=0;
			if(!file_exists($dest.$file['name'])) mkdir($dest.$file['name']);
		} else { //file
			$file['size']=OctDec(trim(substr($tar['data'],($offset+124),12)));
			$file['data']=substr($tar['data'],($offset+512),$file['size']);
			//UTF8+Unix conversion dei file di testo
			$ext=substr($file['name'],-3);
			if($ext=="txt"|$ext=="php"|$ext=="html"|$ext=="xml")
			{
				$file['data']=str_replace("\r","",$file['data']);
				$file['data']=utf8_decode(utf8_encode($file['data']));
			}
			file_put_contents($dest.$file['name'],$file['data']);
		}
		$offset+=512+$file['size'];
		while(substr($tar['data'],$offset,1)==chr(0))
		{
			$offset++;
		}
	}
}
function kiTgzExtract($file,$dest)
{
	$tmpname='tmp'.date("YmdHis").'.tar';
	copy($file,$dest.'/'.$tmpname.'.gz');
	file_put_contents($dest.'/'.$tmpname,kGzDecode(file_get_contents($dest.'/'.$tmpname.'.gz')));
	unlink($dest.'/'.$tmpname.'.gz');
	kiTarExtract($dest.'/'.$tmpname,$dest);
	unlink($dest.'/'.$tmpname);
}


function smartCopy($source, $dest, $options=array('folderPermission'=>0755,'filePermission'=>0755))
{
	$result=false;
   
	if (is_file($source)) {
		if ($dest[strlen($dest)-1]=='/') {
			if (!file_exists($dest)) {
				cmfcDirectory::makeAll($dest,$options['folderPermission'],true);
			}
			$__dest=$dest."/".basename($source);
		} else {
			$__dest=$dest;
		}
		$result=copy($source, $__dest);
		@chmod($__dest,$options['filePermission']);
	   
	} elseif(is_dir($source)) {
		if ($dest[strlen($dest)-1]=='/') {
			if ($source[strlen($source)-1]=='/') {
				//Copy only contents
			} else {
				//Change parent itself and its contents
				$dest=$dest.basename($source);
				if(!file_exists($dest)) mkdir($dest);
				@chmod($dest,$options['filePermission']);
			}
		} else {
			if ($source[strlen($source)-1]=='/') {
				//Copy parent directory with new name and all its content
				if(!file_exists($dest)) mkdir($dest,$options['folderPermission']);
				@chmod($dest,$options['filePermission']);
			} else {
				//Copy parent directory with new name and all its content
				if(!file_exists($dest)) mkdir($dest,$options['folderPermission']);
				@chmod($dest,$options['filePermission']);
			}
		}

		$dirHandle=opendir($source);
		while($file=readdir($dirHandle))
		{
			if($file!="." && $file!="..")
			{
				 if(!is_dir($source."/".$file)) {
					$__dest=$dest."/".$file;
				} else {
					$__dest=$dest."/".$file;
				}
				//echo "$source/$file ||| $__dest<br />";
				$result=smartCopy($source."/".$file, $__dest, $options);
			}
		}
		closedir($dirHandle);
	   
	} else {
		$result=false;
	}
	return $result;
} 



/* COPY FILES */
kiTgzExtract('tmp/'.$targz,'tmp/');
smartCopy('tmp/admin', BASERELDIR.'admin');
smartCopy('tmp/inc', BASERELDIR.'inc');
smartCopy('tmp/template', BASERELDIR.'template');

if(!file_exists(BASERELDIR.'vendor')) mkdir(BASERELDIR.'vendor');
smartCopy('tmp/vendor', BASERELDIR.'vendor');

if(!file_exists(BASERELDIR.'arch/tmp')) mkdir(BASERELDIR.'arch/tmp');

if(file_exists(ADMINRELDIR.'news/ajax/facebook_create_event.php')) unlink(ADMINRELDIR.'news/ajax/facebook_create_event.php');
if(file_exists(ADMINRELDIR.'inc/facebook')) kRmDir(ADMINRELDIR.'inc/facebook');
unlink('tmp/'.$targz);
echo 'All files was successfully updated.<br />';


/* UPDATE DATABASE */
$filetype_exists = false;
$metadata_exists = false;
$results = ksql_query('SHOW COLUMNS FROM `'.TABLE_IMG.'`');
while($row = ksql_fetch_array($results))
{
	if($row['Field'] == 'filetype') $filetype_exists = true;
	elseif($row['Field'] == 'metadata') $metadata_exists = true;
}
if($filetype_exists == false) ksql_query("ALTER TABLE `".TABLE_IMG."` ADD `filetype` INT( 1 ) NOT NULL DEFAULT '1' AFTER `idimg`");
if($metadata_exists == false) ksql_query("ALTER TABLE `".TABLE_IMG."` ADD `metadata` TEXT NOT NULL AFTER `alt`");


// move medias from table media to table images
$media_refs = array();

$results = ksql_query("SELECT * FROM `".TABLE_MEDIA."`");
while( $row = ksql_fetch_array($results) )
{
	$metadata = array();
	$metadata['width'] = $row['width'];
	$metadata['height'] = $row['height'];
	$metadata['duration'] = $row['duration'];
	$metadata['embedcode'] = $row['htmlcode'];
	$query="INSERT INTO `".TABLE_IMG."` (`filetype`, `filename`, `thumbnail`, `hotlink`, `alt`, `metadata`, `creation_date`) VALUES ("
			."2,"
			."'".ksql_real_escape_string( $row['filename'] )."',"
			."'".ksql_real_escape_string( $row['thumbnail'] )."',"
			."'".ksql_real_escape_string( $row['hotlink'] )."',"
			."'".ksql_real_escape_string( trim($row['title']."\n".$row['alt']) )."',"
			."'".ksql_real_escape_string( serialize($metadata) )."',"
			."NOW()"
			.")";
	if(ksql_query($query)) $media_refs[$row['idmedia']] = ksql_insert_id();
}

// rename media dir 
foreach($media_refs as $idmedia => $idimg)
{
	// before all, rename the old directories, prefixing with an underscore, to avoid to overwrite later
	$odir = BASERELDIR.DIR_MEDIA.$idmedia;
	$ndir = BASERELDIR.DIR_MEDIA.'_'.$idmedia;
	if(file_exists($odir) && is_dir($odir)) rename($odir, $ndir);
}

// where to look for substitutions?
$search=array();
$search[]=array(TABLE_CONFIG,'value1');
$search[]=array(TABLE_CONFIG,'value2');
$search[]=array(TABLE_PAGINE,'anteprima');
$search[]=array(TABLE_PAGINE,'testo');
$search[]=array(TABLE_NEWS,'anteprima');
$search[]=array(TABLE_NEWS,'testo');
$search[]=array(TABLE_PHOTOGALLERY,'testo');
$search[]=array(TABLE_SHOP_ITEMS,'anteprima');
$search[]=array(TABLE_SHOP_ITEMS,'testo');
$search[]=array(TABLE_SHOP_MANUFACTURERS,'preview');
$search[]=array(TABLE_SHOP_MANUFACTURERS,'description');

foreach($media_refs as $idmedia => $idimg)
{
	// then rename all the directories in the equivalent ones
	$odir = BASERELDIR.DIR_MEDIA.'_'.$idmedia;
	$ndir = BASERELDIR.DIR_MEDIA.$idimg;
	if(file_exists($odir) && is_dir($odir)) rename($odir, $ndir);

	// update all the id references
	foreach($search as $s)
	{
		ksql_query("UPDATE `".$s[0]."` SET `".$s[1]."`=REPLACE(`".$s[1]."`, ' id=\"media".$idmedia."\"', ' data-orichalcum-id=\"img".$idimg."\"') WHERE `".$s[1]."` LIKE '% id=\"media".$idmedia."\"%'");
	}
}


// update the old internal id reference (id=) with the new one (data-orichalcum-id=)
foreach($search as $s)
{
	ksql_query("UPDATE `".$s[0]."` SET `".$s[1]."`=REPLACE(`".$s[1]."`, ' id=\"img', ' data-orichalcum-id=\"img') WHERE `".$s[1]."` LIKE '% id=\"img%'");
	ksql_query("UPDATE `".$s[0]."` SET `".$s[1]."`=REPLACE(`".$s[1]."`, ' id=\"thumb', ' data-orichalcum-id=\"thm') WHERE `".$s[1]."` LIKE '% id=\"thumb%'");
	ksql_query("UPDATE `".$s[0]."` SET `".$s[1]."`=REPLACE(`".$s[1]."`, ' id=\"doc', ' data-orichalcum-id=\"doc') WHERE `".$s[1]."` LIKE '% id=\"doc%'");
}



/* CHANGE CONFIG */
$cnfg=file_get_contents('../inc/config.inc.php');

//update version number and constants
$cnfg=str_replace('"SW_VERSION","2.74"','"SW_VERSION","2.80"',$cnfg);
$cnfg=str_replace('define("DIR_PRIVATE","arch/private/");', 'define("DIR_PRIVATE","arch/private/");'."\n".'define("DIR_TEMP","arch/tmp/");', $cnfg);

//save changes
if(!file_put_contents('../inc/config.inc.php',$cnfg)) echo "<strong>Errors occurred during the update of config.inc.php!</strong><br />";
echo 'Config file was successfully updated.<br />';

echo '<br /><h3>WELL DONE! Orichalcum 2.80 is ready to rock.</h3>';

unlink("tmp/install.php");
?>